/*Vishi Pallerla, CS 2010, 3:30p - 4:20p
* Program 5, PallerlaV_pgm5.cpp, 11/5/21
* 
* Purpose: Take the Ohio weather data and find the highest maximum temperature, lowest minimum temperature, maximum humidity, fastest wind
* speed, most precipitation, and the average of each section. Put the new data into a report.
* 
* Input: A file called "pgm5.txt" is inputted into the pprogram. The text file contains Ohio weather data from September to October of 2021.
* The data includes the maximum and minimum temperature, humidity, wind speed, and precipitation of each day.
* 
* Processing: Input data is taken from "pgm5.txt" and put into parallel arrays. The dates for the highest maximum temperature, lowest
* minimum temperature, maximum humidity, fastest wind speed, and most precipitation are found and printed out, along with the average
* of each section. The output data is then put into "report.txt".
* 
* Output: The dates with the highest maximum temparture, lowest minimum temperature, maximum humidity, fastest wind speed, and most
* precipitation, along with the average for each data point are also printed. All the output data is put into a file called "report.txt".
*/

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

int main() {
	//constant value, max number of days possible
	const int DAYS = 61;
	//files
	ifstream inFile;
	ofstream outFile;
	//arrays
	int maxTemp[DAYS];
	int minTemp[DAYS];
	int humidity[DAYS];
	int windSpeed[DAYS];
	double totalPrecip[DAYS];
	//comparison values
	int highestTemp;
	int lowestTemp;
	int highestHumid;
	int highestWS;
	double highestTP;
	//total number of days
	int numDays = 0;
	//days of comparison values, derived from index of arrays
	int hottestDay = 0;
	int coldestDay = 0;
	int mostHumidDay = 0;
	int windiestDay = 0;
	int wettestDay = 0;
	//dates of comparison values, derived from days
	string hotDate;
	string coldDate;
	string humidDate;
	string windyDate;
	string wetDate;
	//temporary string
	string s;
	//totals, used to calculate averages
	int totalHot = 0.0;
	int totalCold = 0.0;
	int totalHumid = 0.0;
	int totalWS = 0.0;
	double totalTP = 0.0;
	//final day and month
	int finalDay = 0;
	string finalMonth = "September";

	//opens the input file - pgm5.txt
	inFile.open("pgm5.txt");
	if (!inFile.is_open()) {
		cout << "Could not open pgm5.txt file" << endl;
		return 1;
	}
	//opens the output file - report.txt
	outFile.open("report.txt");
	if (!outFile.is_open()) {
		cout << "Could not open report.txt file" << endl;
		return 1;
	}

	//initializes arrays with values from pgm5.txt
	while (!inFile.eof()) {
		inFile >> maxTemp[numDays];
		inFile >> minTemp[numDays];
		inFile >> humidity[numDays];
		inFile >> windSpeed[numDays];
		inFile >> totalPrecip[numDays];
		++numDays;
	}

	//initializes the values that need to be compared
	highestTemp = maxTemp[0];
	lowestTemp = minTemp[0];
	highestHumid = humidity[0];
	highestWS = windSpeed[0];
	highestTP = totalPrecip[0];

	//for loop to update the comparison values as needed
	for (int i = 0; i < numDays; ++i) {
		if (highestTemp <= maxTemp[i]) {
			highestTemp = maxTemp[i];
			hottestDay = i;
		}
		if (lowestTemp >= minTemp[i]) {
			lowestTemp = minTemp[i];
			coldestDay = i;
		}
		if (highestHumid <= humidity[i]) {
			highestHumid = humidity[i];
			mostHumidDay = i;
		}
		if (highestWS <= windSpeed[i]) {
			highestWS = windSpeed[i];
			windiestDay = i;
		}
		if (highestTP <= totalPrecip[i]) {
			highestTP = totalPrecip[i];
			wettestDay = i;
		}
		//finds total values for calculating averages
		totalHot += maxTemp[i];
		totalCold += minTemp[i];
		totalHumid += humidity[i];
		totalWS += windSpeed[i];
		totalTP += totalPrecip[i];
	}

	//gets the hottest day in date format
	if (hottestDay + 1 > 30) {
		s = to_string(hottestDay - 29);
		hotDate = "10/" + s + "/21";
	}
	else {
		s = to_string(hottestDay + 1);
		hotDate = "09/" + s + "/21";
	}
	//gets the coldest day in date format
	if (coldestDay + 1 > 30) {
		s = to_string(coldestDay - 29);
		coldDate = "10/" + s + "/21";
	}
	else {
		s = to_string(coldestDay + 1);
		coldDate = "09/" + s + "/21";
	}
	//gets the most humid day in date format
	if (mostHumidDay + 1 > 30) {
		s = to_string(mostHumidDay - 29);
		humidDate = "10/" + s + "/21";
	}
	else {
		s = to_string(mostHumidDay + 1);
		humidDate = "09/" + s + "/21";
	}
	//gets the windiest day in date format
	if (windiestDay + 1 > 30) {
		s = to_string(windiestDay - 29);
		windyDate = "10/" + s + "/21";
	}
	else {
		s = to_string(windiestDay + 1);
		windyDate = "09/" + s + "/21";
	}
	//gets the wettest day in date format
	if (wettestDay > 30) {
		s = to_string(wettestDay - 29);
		wetDate = "10/" + s + "/21";
	}
	else {
		s = to_string(wettestDay + 1);
		wetDate = "09/" + s + "/21";
	}
	
	//finds final day and month
	finalDay = numDays;
	if (finalDay > 30) {
		finalDay -= 30;
		finalMonth = "October";
	}

	//outputs data
	cout << fixed << setprecision(2);
	cout << "\t\tOhio Weather Analysis (September 1, 2021 - " << finalMonth << " " << finalDay << ", 2021)" << endl;
	cout << "              Date      H.Temp   C.Temp   Max Humidity   Max Wind   Precipitation" << endl;
	cout << "----------------------------------------------------------------------------------------" << endl;

	cout << "Hottest      " << setw(8) << hotDate << setw(6) << maxTemp[hottestDay] << "F ";
	cout << setw(6) << minTemp[hottestDay] << "F " << setw(12) << humidity[hottestDay] << "% ";
	cout << setw(8) << windSpeed[hottestDay] << " mph " << setw(13) << totalPrecip[hottestDay] << " in" << endl;

	cout << "Coldest      " << setw(8) << coldDate << setw(6) << maxTemp[coldestDay] << "F ";
	cout << setw(6) << minTemp[coldestDay] << "F " << setw(12) << humidity[coldestDay] << "% ";
	cout << setw(8) << windSpeed[coldestDay] << " mph " << setw(13) << totalPrecip[coldestDay] << " in" << endl;

	cout << "Most Humid   " << setw(8) << humidDate << setw(6) << maxTemp[mostHumidDay] << "F ";
	cout << setw(6) << minTemp[mostHumidDay] << "F " << setw(12) << humidity[mostHumidDay] << "% ";
	cout << setw(8) << windSpeed[mostHumidDay] << " mph " << setw(13) << totalPrecip[mostHumidDay] << " in" << endl;

	cout << "Windiest     " << setw(8) << windyDate << setw(6) << maxTemp[windiestDay] << "F ";
	cout << setw(6) << minTemp[windiestDay] << "F " << setw(12) << humidity[windiestDay] << "% ";
	cout << setw(8) << windSpeed[windiestDay] << " mph " << setw(13) << totalPrecip[windiestDay] << " in" << endl;

	cout << "Wettest      " << setw(8) << wetDate << setw(6) << maxTemp[wettestDay] << "F ";
	cout << setw(6) << minTemp[wettestDay] << "F " << setw(12) << humidity[wettestDay] << "% ";
	cout << setw(8) << windSpeed[wettestDay] << " mph " << setw(13) << totalPrecip[wettestDay] << " in" << endl;

	cout << "----------------------------------------------------------------------------------------" << endl;
	cout << "AVERAGE              " << setw(6) << totalHot / numDays << "F " << setw(6) << totalCold / numDays << "F       ";
	cout << setw(6) << totalHumid / numDays << "% " << setw(8) << totalWS / numDays << " mph ";
	cout << setw(13) << totalTP / numDays << " in" << endl;

	//puts data into report.txt
	outFile << fixed << setprecision(2);
	outFile << "\t\tOhio Weather Analysis (September 1, 2021 - " << finalMonth << " " << finalDay << ", 2021)" << endl;
	outFile << "              Date      H.Temp   C.Temp   Max Humidity   Max Wind   Precipitation" << endl;
	outFile << "----------------------------------------------------------------------------------------" << endl;

	outFile << "Hottest      " << setw(8) << hotDate << setw(6) << maxTemp[hottestDay] << "F ";
	outFile << setw(6) << minTemp[hottestDay] << "F " << setw(12) << humidity[hottestDay] << "% ";
	outFile << setw(8) << windSpeed[hottestDay] << " mph " << setw(13) << totalPrecip[hottestDay] << " in" << endl;

	outFile << "Coldest      " << setw(8) << coldDate << setw(6) << maxTemp[coldestDay] << "F ";
	outFile << setw(6) << minTemp[coldestDay] << "F " << setw(12) << humidity[coldestDay] << "% ";
	outFile << setw(8) << windSpeed[coldestDay] << " mph " << setw(13) << totalPrecip[coldestDay] << " in" << endl;

	outFile << "Most Humid   " << setw(8) << humidDate << setw(6) << maxTemp[mostHumidDay] << "F ";
	outFile << setw(6) << minTemp[mostHumidDay] << "F " << setw(12) << humidity[mostHumidDay] << "% ";
	outFile << setw(8) << windSpeed[mostHumidDay] << " mph " << setw(13) << totalPrecip[mostHumidDay] << " in" << endl;

	outFile << "Windiest     " << setw(8) << windyDate << setw(6) << maxTemp[windiestDay] << "F ";
	outFile << setw(6) << minTemp[windiestDay] << "F " << setw(12) << humidity[windiestDay] << "% ";
	outFile << setw(8) << windSpeed[windiestDay] << " mph " << setw(13) << totalPrecip[windiestDay] << " in" << endl;

	outFile << "Wettest      " << setw(8) << wetDate << setw(6) << maxTemp[wettestDay] << "F ";
	outFile << setw(6) << minTemp[wettestDay] << "F " << setw(12) << humidity[wettestDay] << "% ";
	outFile << setw(8) << windSpeed[wettestDay] << " mph " << setw(13) << totalPrecip[wettestDay] << " in" << endl;

	outFile << "----------------------------------------------------------------------------------------" << endl;
	outFile << "AVERAGE              " << setw(6) << totalHot / numDays << "F " << setw(6) << totalCold / numDays << "F       ";
	outFile << setw(6) << totalHumid / numDays << "% " << setw(8) << totalWS / numDays << " mph ";
	outFile << setw(13) << totalTP / numDays << " in" << endl;

	//closes files
	inFile.close();
	outFile.close();

	return 0;
}